import Database from 'better-sqlite3';
import { v4 as uuidv4 } from 'uuid';

const db = new Database('clinic.db');

// Ensure table exists
db.exec(`
  CREATE TABLE IF NOT EXISTS appointments (
    id TEXT PRIMARY KEY,
    patient_name TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    symptoms TEXT,
    status TEXT DEFAULT 'confirmed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

const sampleData = [
  {
    id: uuidv4().slice(0, 8).toUpperCase(),
    patient_name: "Sarah Jenkins",
    date: "2026-03-15",
    time: "10:30 AM",
    symptoms: "Persistent dry cough and mild fever for 3 days."
  },
  {
    id: uuidv4().slice(0, 8).toUpperCase(),
    patient_name: "Michael Chen",
    date: "2026-03-15",
    time: "02:15 PM",
    symptoms: "Sprained ankle from playing basketball."
  },
  {
    id: uuidv4().slice(0, 8).toUpperCase(),
    patient_name: "Elena Rodriguez",
    date: "2026-03-16",
    time: "09:00 AM",
    symptoms: "Annual physical checkup and blood work."
  },
  {
    id: uuidv4().slice(0, 8).toUpperCase(),
    patient_name: "David Smith",
    date: "2026-03-17",
    time: "11:45 AM",
    symptoms: "Severe seasonal allergies and sinus pressure."
  }
];

const insert = db.prepare(`
  INSERT INTO appointments (id, patient_name, date, time, symptoms)
  VALUES (?, ?, ?, ?, ?)
`);

console.log("🌱 Seeding clinic data...");

db.transaction(() => {
  for (const apt of sampleData) {
    insert.run(apt.id, apt.patient_name, apt.date, apt.time, apt.symptoms);
    console.log(`✅ Added appointment for ${apt.patient_name} (ID: ${apt.id})`);
  }
})();

console.log("✨ Seeding complete!");
db.close();
