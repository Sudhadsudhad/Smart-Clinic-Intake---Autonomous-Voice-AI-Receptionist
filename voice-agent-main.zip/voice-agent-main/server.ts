import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { appointmentRepo } from "./src/db.ts";
import { v4 as uuidv4 } from 'uuid';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API Routes ---
  
  // Get Doctors
  app.get("/api/doctors", (req, res) => {
    res.json(appointmentRepo.getDoctors());
  });

  // Book Appointment
  app.post("/api/appointments", (req, res) => {
    const { name, date, time, symptoms, doctorId } = req.body;
    console.log("Booking request received:", { name, date, time, doctorId });
    
    // Basic validation: Clinic closed on Sundays
    // Parse date safely to avoid timezone shifts
    const [year, month, day] = date.split('-').map(Number);
    const appointmentDate = new Date(year, month - 1, day);
    
    if (appointmentDate.getDay() === 0) {
      return res.status(400).json({ 
        status: "error", 
        message: "The clinic is closed on Sundays. Please choose another day." 
      });
    }

    // Check if slot is busy for the specific doctor
    try {
      const existingAppointments = appointmentRepo.getAll();
      const isBusy = existingAppointments.some(apt => 
        apt.date === date && 
        apt.time === time && 
        apt.status === 'confirmed' &&
        apt.doctor_id === (doctorId || 'd1')
      );

      if (isBusy) {
        return res.status(400).json({
          status: "error",
          message: "This time slot is already booked for this doctor. Please choose another time or doctor."
        });
      }

      const id = uuidv4().slice(0, 8).toUpperCase();
      const result = appointmentRepo.create({ 
        id, 
        patient_name: name, 
        doctor_id: doctorId || 'd1',
        date, 
        time, 
        symptoms 
      });
      console.log("Appointment created successfully:", id);
      res.json(result);
    } catch (error) {
      console.error("Database error during booking:", error);
      res.status(500).json({ status: "error", message: "Failed to book appointment due to a server error." });
    }
  });

  // Check Appointment
  app.get("/api/appointments/:id", (req, res) => {
    const appointment = appointmentRepo.getById(req.params.id);
    if (appointment) {
      res.json(appointment);
    } else {
      res.status(404).json({ status: "error", message: "Appointment not found" });
    }
  });

  // Cancel Appointment
  app.delete("/api/appointments/:id", (req, res) => {
    const success = appointmentRepo.cancel(req.params.id);
    if (success) {
      res.json({ status: "success", message: "Appointment cancelled" });
    } else {
      res.status(404).json({ status: "error", message: "Appointment not found" });
    }
  });

  // Get All (for dashboard)
  app.get("/api/appointments", (req, res) => {
    res.json(appointmentRepo.getAll());
  });

  // Emergency Escalation (Mock)
  app.post("/api/emergency", (req, res) => {
    const { symptoms } = req.body;
    console.log("EMERGENCY ESCALATED:", symptoms);
    res.json({ 
      status: "escalated", 
      message: "Emergency protocol activated. A medical professional has been notified." 
    });
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
