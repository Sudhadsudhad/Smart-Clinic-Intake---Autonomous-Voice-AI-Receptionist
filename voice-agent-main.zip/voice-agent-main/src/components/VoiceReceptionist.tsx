import { GoogleGenAI, LiveServerMessage, Modality, Type } from "@google/genai";
import { useEffect, useRef, useState } from "react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { Phone } from "lucide-react";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface VoiceReceptionistProps {
  onAppointmentBooked: (appointment?: any) => void;
}

export function VoiceReceptionist({ onAppointmentBooked }: VoiceReceptionistProps) {
  const [isActive, setIsActive] = useState(false);
  const [status, setStatus] = useState<string>("Ready to help");
  const [transcript, setTranscript] = useState<string[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const audioQueue = useRef<Int16Array[]>([]);
  const isPlaying = useRef(false);

  // Tools Implementation
  const tools = [
    {
      functionDeclarations: [
        {
          name: "bookAppointment",
          description: "Books a new appointment for a patient. Clinic is closed on Sundays.",
          parameters: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: "Patient's full name" },
              doctorId: { type: Type.STRING, description: "Doctor ID (d1: Dr. Rahul, d2: Dr. Priya, d3: Dr. Arjun)" },
              date: { type: Type.STRING, description: "Date of appointment (YYYY-MM-DD)" },
              time: { type: Type.STRING, description: "Time of appointment (e.g., 09:00 AM, 10:00 AM, 11:00 AM, 12:00 PM, 02:00 PM, 03:00 PM, 04:00 PM)" },
              symptoms: { type: Type.STRING, description: "Brief description of symptoms" },
            },
            required: ["name", "doctorId", "date", "time", "symptoms"],
          },
        },
        {
          name: "checkAppointment",
          description: "Checks the status of an existing appointment using an ID.",
          parameters: {
            type: Type.OBJECT,
            properties: {
              appointmentId: { type: Type.STRING, description: "The 8-character appointment ID" },
            },
            required: ["appointmentId"],
          },
        },
        {
          name: "cancelAppointment",
          description: "Cancels an existing appointment.",
          parameters: {
            type: Type.OBJECT,
            properties: {
              appointmentId: { type: Type.STRING, description: "The 8-character appointment ID" },
            },
            required: ["appointmentId"],
          },
        },
        {
          name: "escalateEmergency",
          description: "Escalates a medical emergency to a human professional.",
          parameters: {
            type: Type.OBJECT,
            properties: {
              symptoms: { type: Type.STRING, description: "The emergency symptoms described" },
            },
            required: ["symptoms"],
          },
        },
      ],
    },
  ];

  const handleToolCall = async (call: any) => {
    const { name, args } = call;
    console.log("Tool Call:", name, args);

    try {
      let response;
      if (name === "bookAppointment") {
        const res = await fetch("/api/appointments", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(args),
        });
        response = await res.json();
        if (response.status === "success") {
          // The server returns { id, status } but we want to save more to history
          // We'll pass the args (name, date, time) + the new ID
          const doctorMap: Record<string, string> = { 
            'dr-priya': 'Dr. Priya', 
            'dr-arjun': 'Dr. Arjun', 
            'dr-sarah': 'Dr. Sarah',
            'dr-mike': 'Dr. Mike',
            'dr-elena': 'Dr. Elena',
            'dr-david': 'Dr. David',
            'dr-chen': 'Dr. Chen',
            'dr-gupta': 'Dr. Gupta',
            'dr-patel': 'Dr. Patel'
          };
          onAppointmentBooked({ ...args, id: response.id, doctor_name: doctorMap[args.doctorId] });
        } else if (response.status === "error") {
          // Pass the error message back to the AI
          return { status: "error", message: response.message };
        }
      } else if (name === "checkAppointment") {
        const res = await fetch(`/api/appointments/${args.appointmentId}`);
        response = await res.json();
      } else if (name === "cancelAppointment") {
        const res = await fetch(`/api/appointments/${args.appointmentId}`, {
          method: "DELETE",
        });
        response = await res.json();
        if (response.status === "success") {
          onAppointmentBooked({ id: args.appointmentId, status: 'cancelled' });
        }
      } else if (name === "escalateEmergency") {
        const res = await fetch("/api/emergency", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(args),
        });
        response = await res.json();
      }

      return response;
    } catch (error) {
      return { status: "error", message: "System error occurred." };
    }
  };

  const startCall = async () => {
    try {
      setStatus("Connecting...");
      setIsActive(true);

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      audioContextRef.current = new AudioContext({ sampleRate: 16000 });
      
      const session = await ai.live.connect({
        model: "gemini-2.5-flash-native-audio-preview-09-2025",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Puck" } },
          },
          systemInstruction: `You are a professional and empathetic clinic receptionist for "Health Clinic". 
          Your goal is to help patients book, check, or cancel appointments.
          
          Doctors Available:
          - Dr. Priya (ID: dr-priya) - General Physician
          - Dr. Arjun (ID: dr-arjun) - General Physician
          - Dr. Sarah (ID: dr-sarah) - Dentist
          - Dr. Mike (ID: dr-mike) - Dermatologist
          - Dr. Elena (ID: dr-elena) - Cardiologist
          - Dr. David (ID: dr-david) - Ophthalmologist
          - Dr. Chen (ID: dr-chen) - Neurologist
          - Dr. Gupta (ID: dr-gupta) - ENT Specialist
          - Dr. Patel (ID: dr-patel) - Orthopedic Doctor

          Standard Time Slots: 09:00 AM, 10:00 AM, 11:00 AM, 12:00 PM, 02:00 PM, 03:00 PM, 04:00 PM.

          Guidelines:
          1. Be concise and helpful.
          2. If symptoms sound life-threatening (chest pain, severe bleeding, difficulty breathing), immediately use the escalateEmergency tool.
          3. Confirm doctor, date, and time before booking.
          4. The clinic is closed on Sundays. If a user asks for Sunday, explain this and offer Monday.
          5. Always provide the appointment ID after a successful booking.
          
          Current Date: ${new Date().toLocaleDateString()}
          `,
          tools: tools,
        },
        callbacks: {
          onopen: () => {
            setStatus("Listening...");
            startMic();
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.modelTurn?.parts) {
              for (const part of message.serverContent.modelTurn.parts) {
                if (part.inlineData) {
                  const audioData = base64ToUint8Array(part.inlineData.data);
                  audioQueue.current.push(new Int16Array(audioData.buffer));
                  if (!isPlaying.current) playNextInQueue();
                }
              }
            }

            if (message.serverContent?.interrupted) {
              audioQueue.current = [];
              isPlaying.current = false;
            }

            if (message.toolCall) {
              const responses = [];
              for (const call of message.toolCall.functionCalls) {
                const result = await handleToolCall(call);
                responses.push({
                  name: call.name,
                  id: call.id,
                  response: { result },
                });
              }
              sessionRef.current.sendToolResponse({ functionResponses: responses });
            }

            if (message.serverContent?.modelTurn?.parts?.[0]?.text) {
              // Handle transcription if needed
            }
          },
          onclose: () => stopCall(),
          onerror: (e) => {
            console.error(e);
            stopCall();
          },
        },
      });

      sessionRef.current = session;
    } catch (error) {
      console.error(error);
      stopCall();
    }
  };

  const startMic = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    streamRef.current = stream;
    
    const source = audioContextRef.current!.createMediaStreamSource(stream);
    const processor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
    processorRef.current = processor;

    processor.onaudioprocess = (e) => {
      const inputData = e.inputBuffer.getChannelData(0);
      const pcmData = floatTo16BitPCM(inputData);
      const base64Data = uint8ArrayToBase64(new Uint8Array(pcmData.buffer));
      
      sessionRef.current?.sendRealtimeInput({
        media: { data: base64Data, mimeType: "audio/pcm;rate=16000" },
      });
    };

    source.connect(processor);
    processor.connect(audioContextRef.current!.destination);
  };

  const stopCall = () => {
    setIsActive(false);
    setStatus("Ready to help");
    streamRef.current?.getTracks().forEach((t) => t.stop());
    processorRef.current?.disconnect();
    sessionRef.current?.close();
    audioQueue.current = [];
    isPlaying.current = false;
  };

  const playNextInQueue = async () => {
    if (audioQueue.current.length === 0) {
      isPlaying.current = false;
      return;
    }

    isPlaying.current = true;
    const pcmData = audioQueue.current.shift()!;
    const floatData = new Float32Array(pcmData.length);
    for (let i = 0; i < pcmData.length; i++) {
      floatData[i] = pcmData[i] / 32768;
    }

    const buffer = audioContextRef.current!.createBuffer(1, floatData.length, 24000);
    buffer.getChannelData(0).set(floatData);

    const source = audioContextRef.current!.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current!.destination);
    source.onended = playNextInQueue;
    source.start();
  };

  return (
    <div className="flex flex-col items-center justify-center p-8 bg-white rounded-3xl shadow-xl border border-slate-100 max-w-md w-full">
      <div className="flex flex-col items-center mb-8">
        <div className="mb-2 p-2 bg-blue-50 rounded-full">
          <Phone className="w-4 h-4 text-blue-600" />
        </div>
        <div className="relative">
          <div className={cn(
            "w-32 h-32 rounded-full flex items-center justify-center transition-all duration-500",
            isActive ? "bg-emerald-500 scale-110 shadow-emerald-200 shadow-2xl" : "bg-slate-100"
          )}>
            {isActive ? (
              <div className="flex gap-1">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="w-1.5 h-8 bg-white rounded-full animate-bounce"
                    style={{ animationDelay: `${i * 0.1}s` }}
                  />
                ))}
              </div>
            ) : (
              <Phone className="w-10 h-10 text-slate-400" />
            )}
          </div>
        </div>
      </div>

      <h2 className="text-2xl font-semibold text-slate-800 mb-2">Clinic Receptionist</h2>
      <p className="text-slate-500 mb-8 text-center">{status}</p>

      <button
        onClick={isActive ? stopCall : startCall}
        className={cn(
          "w-full py-4 rounded-2xl font-medium transition-all active:scale-95",
          isActive 
            ? "bg-rose-50 text-rose-600 hover:bg-rose-100" 
            : "bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-100"
        )}
      >
        {isActive ? "End Call" : "Call Clinic"}
      </button>

      {isActive && (
        <div className="mt-6 w-full p-4 bg-slate-50 rounded-xl border border-slate-100">
          <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">Live Status</p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
            <span className="text-sm text-slate-600">AI is listening for your request...</span>
          </div>
        </div>
      )}
    </div>
  );
}

// Helper functions
function floatTo16BitPCM(input: Float32Array) {
  const output = new Int16Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i]));
    output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return output;
}

function base64ToUint8Array(base64: string) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function uint8ArrayToBase64(bytes: Uint8Array) {
  let binary = "";
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}
