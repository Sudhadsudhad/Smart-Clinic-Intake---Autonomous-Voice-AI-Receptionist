import { useState, useEffect } from "react";
import { Search, Calendar, Clock, User, CheckCircle2, AlertCircle, ArrowRight, UserCheck } from "lucide-react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Doctor {
  id: string;
  name: string;
  specialization: string;
  schedule: {
    [key: string]: string[]; // Day: Array of slots
  };
}

const SYMPTOMS_MAPPING: { [key: string]: string[] } = {
  "Fever": ["General Physician"],
  "Headache": ["General Physician"],
  "Body Pain": ["General Physician", "Orthopedic Doctor"],
  "Stomach Pain": ["General Physician"],
  "Tooth Pain": ["Dentist"],
  "Cold": ["General Physician"],
  "Cough": ["General Physician"],
  "Vomiting": ["General Physician"],
  "Skin Rash": ["Dermatologist"],
  "Chest Pain": ["Cardiologist"],
  "Eye Pain": ["Ophthalmologist"],
  "Ear Pain": ["ENT Specialist"],
  "Back Pain": ["Orthopedic Doctor"],
  "Throat Pain": ["ENT Specialist"],
  "Dizziness": ["Neurologist"],
};

const DOCTORS: Doctor[] = [
  {
    id: "dr-priya",
    name: "Dr. Priya",
    specialization: "General Physician",
    schedule: {
      "Monday": ["09:00 AM", "10:00 AM", "11:00 AM"],
      "Tuesday": ["10:00 AM", "11:00 AM", "12:00 PM"],
      "Wednesday": ["09:00 AM", "10:00 AM", "11:00 AM"],
      "Friday": ["02:00 PM", "03:00 PM", "04:00 PM"],
    }
  },
  {
    id: "dr-arjun",
    name: "Dr. Arjun",
    specialization: "General Physician",
    schedule: {
      "Monday": ["01:00 PM", "02:00 PM", "03:00 PM"],
      "Tuesday": ["02:00 PM", "03:00 PM", "04:00 PM"],
      "Thursday": ["09:00 AM", "10:00 AM", "11:00 AM"],
      "Friday": ["09:00 AM", "10:00 AM", "11:00 AM"],
    }
  },
  {
    id: "dr-sarah",
    name: "Dr. Sarah",
    specialization: "Dentist",
    schedule: {
      "Monday": ["09:00 AM", "10:00 AM", "11:00 AM"],
      "Wednesday": ["02:00 PM", "03:00 PM", "04:00 PM"],
      "Friday": ["10:00 AM", "11:00 AM", "12:00 PM"],
    }
  },
  {
    id: "dr-mike",
    name: "Dr. Mike",
    specialization: "Dermatologist",
    schedule: {
      "Tuesday": ["09:00 AM", "10:00 AM", "11:00 AM"],
      "Thursday": ["02:00 PM", "03:00 PM", "04:00 PM"],
    }
  },
  {
    id: "dr-elena",
    name: "Dr. Elena",
    specialization: "Cardiologist",
    schedule: {
      "Monday": ["10:00 AM", "11:00 AM"],
      "Wednesday": ["10:00 AM", "11:00 AM"],
      "Friday": ["10:00 AM", "11:00 AM"],
    }
  },
  {
    id: "dr-david",
    name: "Dr. David",
    specialization: "Ophthalmologist",
    schedule: {
      "Tuesday": ["02:00 PM", "03:00 PM"],
      "Thursday": ["09:00 AM", "10:00 AM"],
    }
  },
  {
    id: "dr-chen",
    name: "Dr. Chen",
    specialization: "Neurologist",
    schedule: {
      "Wednesday": ["09:00 AM", "10:00 AM", "11:00 AM"],
      "Friday": ["02:00 PM", "03:00 PM", "04:00 PM"],
    }
  },
  {
    id: "dr-gupta",
    name: "Dr. Gupta",
    specialization: "ENT Specialist",
    schedule: {
      "Monday": ["09:00 AM", "10:00 AM"],
      "Thursday": ["02:00 PM", "03:00 PM"],
    }
  },
  {
    id: "dr-patel",
    name: "Dr. Patel",
    specialization: "Orthopedic Doctor",
    schedule: {
      "Wednesday": ["01:00 PM", "02:00 PM", "03:00 PM"],
      "Friday": ["09:00 AM", "10:00 AM"],
    }
  }
];

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

interface DoctorAvailabilityProps {
  onBookingSuccess: (appointment: any) => void;
  onNavigateToDashboard?: () => void;
  user: { name: string; email: string };
}

export function DoctorAvailability({ onBookingSuccess, onNavigateToDashboard, user }: DoctorAvailabilityProps) {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [recommendedSpecializations, setRecommendedSpecializations] = useState<string[]>([]);
  const [recommendedDoctors, setRecommendedDoctors] = useState<Doctor[]>([]);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedDay, setSelectedDay] = useState<string>("");
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<string>("");
  const [bookingStatus, setBookingStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [alternativeDoctor, setAlternativeDoctor] = useState<Doctor | null>(null);

  const toggleSymptom = (symptom: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(symptom) 
        ? prev.filter(s => s !== symptom) 
        : [...prev, symptom]
    );
  };

  // Logic to determine recommended specialization
  useEffect(() => {
    if (selectedSymptoms.length > 0) {
      const specs = new Set<string>();
      selectedSymptoms.forEach(s => {
        const mapping = SYMPTOMS_MAPPING[s] || [];
        mapping.forEach(spec => specs.add(spec));
      });
      
      const specsArray = Array.from(specs);
      setRecommendedSpecializations(specsArray);
      
      const filtered = DOCTORS.filter(doc => specs.has(doc.specialization));
      setRecommendedDoctors(filtered);
      
      // Reset subsequent selections when symptoms change
      setSelectedDoctor(null);
      setSelectedDay("");
      setAvailableSlots([]);
      setSelectedSlot("");
      setAlternativeDoctor(null);
    } else {
      setRecommendedSpecializations([]);
      setRecommendedDoctors([]);
      setSelectedDoctor(null);
    }
  }, [selectedSymptoms]);

  // Update slots when doctor or day changes
  useEffect(() => {
    if (selectedDoctor && selectedDay) {
      const slots = selectedDoctor.schedule[selectedDay] || [];
      setAvailableSlots(slots);
      setSelectedSlot("");

      // If no slots, look for alternative
      if (slots.length === 0) {
        const alt = recommendedDoctors.find(d => 
          d.id !== selectedDoctor.id && 
          d.specialization === selectedDoctor.specialization &&
          d.schedule[selectedDay]?.length > 0
        );
        setAlternativeDoctor(alt || null);
      } else {
        setAlternativeDoctor(null);
      }
    }
  }, [selectedDoctor, selectedDay, recommendedDoctors]);

  const handleBook = async () => {
    if (!selectedDoctor || !selectedDay || !selectedSlot) return;

    setBookingStatus("loading");
    try {
      const today = new Date();
      const currentDayIndex = today.getDay();
      const targetDayIndex = DAYS.indexOf(selectedDay) + 1;
      const diff = targetDayIndex - currentDayIndex;
      const targetDate = new Date(today);
      targetDate.setDate(today.getDate() + (diff >= 0 ? diff : diff + 7));
      
      const dateStr = targetDate.toISOString().split('T')[0];

      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: user.name,
          date: dateStr,
          time: selectedSlot,
          symptoms: `Symptoms: ${selectedSymptoms.join(", ")} (Doctor: ${selectedDoctor.name})`,
          doctorId: selectedDoctor.id,
        }),
      });

      const data = await res.json();
      if (data.status === "success") {
        setBookingStatus("success");
        onBookingSuccess({
          id: data.id,
          name: user.name,
          date: dateStr,
          time: selectedSlot,
          symptoms: selectedSymptoms.join(", "),
          doctor_name: selectedDoctor.name
        });
      } else {
        setBookingStatus("error");
        setErrorMessage(data.message || "Failed to book appointment");
      }
    } catch (error) {
      setBookingStatus("error");
      setErrorMessage("System error occurred.");
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-10 text-center">
        <h2 className="text-3xl font-bold text-slate-900 mb-3">Check Symptoms and Find Recommended Doctor</h2>
        <p className="text-slate-500">Select your symptoms and our AI will recommend the best specialist for you.</p>
      </div>

      {/* Symptom Selection */}
      <section className="mb-12">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-blue-100 p-2 rounded-lg">
            <Search className="w-5 h-5 text-blue-600" />
          </div>
          <h3 className="text-xl font-bold text-slate-800">Select your symptoms (Multiple allowed)</h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {Object.keys(SYMPTOMS_MAPPING).map((symptom) => (
            <label
              key={symptom}
              className={cn(
                "flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-medium transition-all border cursor-pointer",
                selectedSymptoms.includes(symptom)
                  ? "bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-100"
                  : "bg-white text-slate-600 border-slate-200 hover:border-blue-300 hover:bg-blue-50"
              )}
            >
              <input 
                type="checkbox" 
                className="hidden"
                checked={selectedSymptoms.includes(symptom)}
                onChange={() => toggleSymptom(symptom)}
              />
              {symptom}
            </label>
          ))}
        </div>
      </section>

      {selectedSymptoms.length > 0 && (
        <>
          {/* AI Recommendation */}
          <div className="mb-12 p-6 bg-blue-50 rounded-3xl border border-blue-100 flex items-center justify-between animate-in fade-in slide-in-from-top-4">
            <div>
              <p className="text-xs font-bold text-blue-500 uppercase tracking-widest mb-1">AI Recommendation</p>
              <h3 className="text-xl font-bold text-slate-900">
                Recommended Specialists: <span className="text-blue-600">{recommendedSpecializations.join(", ")}</span>
              </h3>
            </div>
            <div className="hidden sm:block bg-white p-3 rounded-2xl shadow-sm">
              <UserCheck className="w-8 h-8 text-blue-600" />
            </div>
          </div>

          {/* Recommended Doctors */}
          <section className="mb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-emerald-100 p-2 rounded-lg">
                <User className="w-5 h-5 text-emerald-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-800">Available Specialists</h3>
            </div>
            <div className="grid sm:grid-cols-2 gap-6">
              {recommendedDoctors.map((doc) => (
                <button
                  key={doc.id}
                  onClick={() => setSelectedDoctor(doc)}
                  className={cn(
                    "p-6 rounded-3xl border-2 text-left transition-all group",
                    selectedDoctor?.id === doc.id
                      ? "border-blue-600 bg-blue-50/50"
                      : "border-slate-100 bg-white hover:border-blue-200"
                  )}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                      <User className="w-6 h-6 text-slate-400 group-hover:text-blue-600" />
                    </div>
                    {selectedDoctor?.id === doc.id && (
                      <CheckCircle2 className="w-6 h-6 text-blue-600" />
                    )}
                  </div>
                  <h4 className="text-lg font-bold text-slate-900">{doc.name}</h4>
                  <p className="text-sm text-blue-600 font-medium">{doc.specialization}</p>
                  
                  <div className="mt-4 pt-4 border-t border-slate-100">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Weekly Schedule</p>
                    <div className="flex flex-wrap gap-2">
                      {DAYS.map(day => (
                        <span 
                          key={day}
                          className={cn(
                            "text-[10px] px-2 py-1 rounded-md font-bold",
                            doc.schedule[day] ? "bg-emerald-50 text-emerald-600" : "bg-slate-50 text-slate-300"
                          )}
                        >
                          {day.slice(0, 3)}
                        </span>
                      ))}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>

          {selectedDoctor && (
            <section className="mb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-amber-100 p-2 rounded-lg">
                  <Calendar className="w-5 h-5 text-amber-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-800">Select a Day</h3>
              </div>
              <div className="flex flex-wrap gap-3">
                {DAYS.map((day) => (
                  <button
                    key={day}
                    onClick={() => setSelectedDay(day)}
                    className={cn(
                      "px-6 py-3 rounded-2xl text-sm font-bold transition-all border",
                      selectedDay === day
                        ? "bg-slate-900 text-white border-slate-900"
                        : "bg-white text-slate-600 border-slate-200 hover:border-slate-300"
                    )}
                  >
                    {day}
                  </button>
                ))}
              </div>

              {selectedDay && (
                <div className="mt-8 p-8 bg-slate-50 rounded-[2rem] border border-slate-100">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <Clock className="w-5 h-5 text-blue-600" />
                    </div>
                    <h4 className="font-bold text-slate-800">Available Slots for {selectedDay}</h4>
                  </div>

                  {availableSlots.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                      {availableSlots.map((slot) => (
                        <button
                          key={slot}
                          onClick={() => setSelectedSlot(slot)}
                          className={cn(
                            "py-3 rounded-xl text-sm font-bold transition-all border",
                            selectedSlot === slot
                              ? "bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-100"
                              : "bg-white text-slate-600 border-slate-200 hover:border-blue-300"
                          )}
                        >
                          {slot}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center py-6 text-center">
                      <div className="bg-rose-50 p-4 rounded-full mb-4">
                        <AlertCircle className="w-8 h-8 text-rose-500" />
                      </div>
                      <p className="text-rose-600 font-bold mb-2">This doctor is currently fully booked on {selectedDay}.</p>
                      
                      {alternativeDoctor && (
                        <div className="mt-4 p-4 bg-emerald-50 border border-emerald-100 rounded-2xl max-w-md">
                          <p className="text-emerald-800 text-sm font-medium mb-3">
                            <span className="font-bold">Alternative Doctor Available:</span> {alternativeDoctor.name} has slots available on this day.
                          </p>
                          <button 
                            onClick={() => setSelectedDoctor(alternativeDoctor)}
                            className="flex items-center gap-2 text-emerald-700 font-bold text-sm hover:underline"
                          >
                            Switch to {alternativeDoctor.name} <ArrowRight className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  {selectedSlot && (
                    <div className="mt-10 pt-8 border-t border-slate-200">
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                        <div>
                          <p className="text-sm text-slate-500 mb-1">Booking for</p>
                          <p className="font-bold text-slate-900">
                            {selectedDoctor.name} • {selectedDay} • {selectedSlot}
                          </p>
                        </div>
                        <button
                          onClick={handleBook}
                          disabled={bookingStatus === "loading"}
                          className={cn(
                            "w-full sm:w-auto px-10 py-4 rounded-2xl font-bold transition-all active:scale-95",
                            bookingStatus === "loading"
                              ? "bg-slate-200 text-slate-400 cursor-not-allowed"
                              : "bg-blue-600 text-white hover:bg-blue-700 shadow-xl shadow-blue-100"
                          )}
                        >
                          {bookingStatus === "loading" ? "Booking..." : "Confirm Appointment"}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </section>
          )}
        </>
      )}

      {/* Status Messages */}
      {bookingStatus === "success" && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-white rounded-[2.5rem] p-10 max-w-md w-full text-center shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-emerald-600" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Booking Confirmed!</h3>
            <p className="text-slate-500 mb-8">Your appointment has been successfully scheduled. You can view it in your dashboard.</p>
            <div className="flex flex-col gap-3">
              <button
                onClick={() => {
                  setBookingStatus("idle");
                  if (onNavigateToDashboard) onNavigateToDashboard();
                }}
                className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
              >
                Go to Dashboard
              </button>
              <button
                onClick={() => setBookingStatus("idle")}
                className="w-full py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all"
              >
                Book Another Appointment
              </button>
            </div>
          </div>
        </div>
      )}

      {bookingStatus === "error" && (
        <div className="mt-6 p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm font-bold">{errorMessage}</p>
        </div>
      )}
    </div>
  );
}
