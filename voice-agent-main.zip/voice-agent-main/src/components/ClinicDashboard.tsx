import { Calendar, Clock, Trash2, CheckCircle2, XCircle, UserCheck } from "lucide-react";
import { useState } from "react";

interface ClinicDashboardProps {
  sessionAppointments: any[];
  onCancel: (id: string) => void;
}

export function ClinicDashboard({ sessionAppointments, onCancel }: ClinicDashboardProps) {
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleCancel = async (id: string) => {
    if (!window.confirm("Are you sure you want to cancel this appointment?")) return;
    
    try {
      const res = await fetch(`/api/appointments/${id}`, { method: "DELETE" });
      const data = await res.json();
      
      if (data.status === "success") {
        onCancel(id);
        showNotification("Appointment cancelled successfully.");
      }
    } catch (error) {
      console.error("Failed to cancel");
      // Fallback for session-only feel if API is not fully synced
      onCancel(id);
      showNotification("Appointment cancelled successfully.");
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6 space-y-8 relative">
      {/* Success Notification */}
      {notification && (
        <div className="fixed top-24 right-8 z-50 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="bg-emerald-600 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-emerald-500">
            <CheckCircle2 className="w-5 h-5" />
            <span className="font-bold">{notification}</span>
          </div>
        </div>
      )}

      {/* Today's Appointment Ledger Section */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <Calendar className="w-6 h-6 text-blue-600" />
            <h2 className="text-2xl font-bold text-slate-800">Today's Appointment Ledger</h2>
          </div>
          <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm font-medium">
            {sessionAppointments.length} Session Bookings
          </span>
        </div>

        {sessionAppointments.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border-2 border-dashed border-slate-200">
            <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500 font-medium">No appointments created in this session.</p>
            <p className="text-xs text-slate-400 mt-2">Your ledger resets every time you log in or out.</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {sessionAppointments.map((apt) => (
              <div
                key={apt.id}
                className={`bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all hover:shadow-md ${
                  apt.status === 'cancelled' ? 'opacity-60 bg-slate-50/50' : ''
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-xl ${apt.status === 'confirmed' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                    {apt.status === 'confirmed' ? <CheckCircle2 className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-slate-800">{apt.patient_name}</h3>
                      <span className="text-xs font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-500">#{apt.id}</span>
                      {apt.status === 'cancelled' && (
                        <span className="text-[10px] bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                          Cancelled
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-1.5 text-sm text-blue-600 font-medium mb-3">
                      <UserCheck className="w-4 h-4" />
                      <span>{apt.doctor_name || 'Dr. Health Assistant'}</span>
                    </div>

                    <div className="flex flex-wrap gap-4 text-sm text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-4 h-4" />
                        {apt.date}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-4 h-4" />
                        {apt.time}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold uppercase text-[10px] tracking-wider">Status:</span>
                        <span className={apt.status === 'confirmed' ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}>
                          {apt.status}
                        </span>
                      </div>
                    </div>
                    <p className="mt-3 text-sm text-slate-600 italic border-l-2 border-slate-200 pl-3">"{apt.symptoms}"</p>
                  </div>
                </div>

                {apt.status === 'confirmed' && (
                  <button
                    onClick={() => handleCancel(apt.id)}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-rose-600 hover:bg-rose-50 border border-rose-100 rounded-xl transition-all whitespace-nowrap"
                    title="Cancel Appointment"
                  >
                    <Trash2 className="w-4 h-4" />
                    Cancel Appointment
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
        <p className="text-[10px] text-slate-400 text-center uppercase tracking-widest font-bold">
          Session-Only Mode Active • Data is not persisted
        </p>
      </div>
    </div>
  );
}
