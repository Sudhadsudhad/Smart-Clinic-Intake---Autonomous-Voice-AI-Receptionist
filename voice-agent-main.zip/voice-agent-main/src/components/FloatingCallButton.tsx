import React from 'react';
import { Phone } from 'lucide-react';
import { motion } from 'motion/react';

interface FloatingCallButtonProps {
  onClick: () => void;
}

export function FloatingCallButton({ onClick }: FloatingCallButtonProps) {
  return (
    <motion.button
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      className="fixed bottom-8 right-8 w-16 h-16 bg-emerald-500 text-white rounded-full shadow-2xl flex items-center justify-center z-50 hover:bg-emerald-600 transition-colors group"
      aria-label="Call Receptionist"
    >
      <Phone className="w-8 h-8 group-hover:rotate-12 transition-transform" />
      <span className="absolute right-full mr-4 px-3 py-1.5 bg-slate-800 text-white text-xs font-bold rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
        Call Receptionist
      </span>
    </motion.button>
  );
}
