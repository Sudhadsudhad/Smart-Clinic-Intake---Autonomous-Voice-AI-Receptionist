import Database from 'better-sqlite3';
import path from 'path';

const db = new Database('clinic.db');

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS doctors (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    specialization TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS appointments (
    id TEXT PRIMARY KEY,
    patient_name TEXT NOT NULL,
    doctor_id TEXT,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    symptoms TEXT,
    status TEXT DEFAULT 'confirmed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id)
  );
`);

// Migration: Add doctor_id to appointments if it doesn't exist
const tableInfo = db.prepare("PRAGMA table_info(appointments)").all() as any[];
const hasDoctorId = tableInfo.some(col => col.name === 'doctor_id');
if (!hasDoctorId) {
  db.exec("ALTER TABLE appointments ADD COLUMN doctor_id TEXT;");
}

// Seed doctors
const insertDoctor = db.prepare('INSERT OR IGNORE INTO doctors (id, name, specialization) VALUES (?, ?, ?)');
insertDoctor.run('dr-priya', 'Dr. Priya', 'General Physician');
insertDoctor.run('dr-arjun', 'Dr. Arjun', 'General Physician');
insertDoctor.run('dr-sarah', 'Dr. Sarah', 'Dentist');
insertDoctor.run('dr-mike', 'Dr. Mike', 'Dermatologist');
insertDoctor.run('dr-elena', 'Dr. Elena', 'Cardiologist');
insertDoctor.run('dr-david', 'Dr. David', 'Ophthalmologist');
insertDoctor.run('dr-chen', 'Dr. Chen', 'Neurologist');
insertDoctor.run('dr-gupta', 'Dr. Gupta', 'ENT Specialist');
insertDoctor.run('dr-patel', 'Dr. Patel', 'Orthopedic Doctor');

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
}

export interface Appointment {
  id: string;
  patient_name: string;
  doctor_id: string;
  doctor_name?: string;
  date: string;
  time: string;
  symptoms: string;
  status: string;
}

export const appointmentRepo = {
  create: (appointment: Omit<Appointment, 'status'>) => {
    const stmt = db.prepare(`
      INSERT INTO appointments (id, patient_name, doctor_id, date, time, symptoms)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    stmt.run(appointment.id, appointment.patient_name, appointment.doctor_id, appointment.date, appointment.time, appointment.symptoms);
    return { id: appointment.id, status: 'success' };
  },

  getById: (id: string): Appointment | undefined => {
    const stmt = db.prepare(`
      SELECT a.*, d.name as doctor_name 
      FROM appointments a 
      LEFT JOIN doctors d ON a.doctor_id = d.id 
      WHERE a.id = ?
    `);
    return stmt.get(id) as Appointment | undefined;
  },

  cancel: (id: string) => {
    const stmt = db.prepare("UPDATE appointments SET status = 'cancelled' WHERE id = ?");
    const result = stmt.run(id);
    return result.changes > 0;
  },

  getAll: (): Appointment[] => {
    const stmt = db.prepare(`
      SELECT a.*, d.name as doctor_name 
      FROM appointments a 
      LEFT JOIN doctors d ON a.doctor_id = d.id 
      ORDER BY a.created_at DESC
    `);
    return stmt.all() as Appointment[];
  },

  getDoctors: (): Doctor[] => {
    return db.prepare('SELECT * FROM doctors').all() as Doctor[];
  }
};
