export interface Appointment {
  id: string;
  patient_name: string;
  doctor_name?: string;
  date: string;
  time: string;
  symptoms: string;
  status: 'confirmed' | 'cancelled';
}

export interface ApiResponse<T> {
  status: 'success' | 'error' | 'escalated';
  message?: string;
  data?: T;
  id?: string;
}
