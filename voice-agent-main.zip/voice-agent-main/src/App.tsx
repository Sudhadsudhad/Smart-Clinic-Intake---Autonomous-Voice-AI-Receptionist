import { useState } from "react";
import { VoiceReceptionist } from "./components/VoiceReceptionist";
import { ClinicDashboard } from "./components/ClinicDashboard";
import { DoctorAvailability } from "./components/DoctorAvailability";
import { AuthPage } from "./components/AuthPage";
import { Stethoscope, LogOut, User, Calendar, LayoutDashboard } from "lucide-react";

export default function App() {
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [sessionAppointments, setSessionAppointments] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<"dashboard" | "availability">("dashboard");

  const handleRefresh = (appointmentData?: any) => {
    // Save to session state if we have appointment data
    if (appointmentData) {
      if (appointmentData.status === 'cancelled') {
        handleCancelSessionAppointment(appointmentData.id);
        return;
      }

      const newHistoryItem = {
        id: appointmentData.id,
        patient_name: appointmentData.name || user?.name || 'Patient',
        doctor_name: appointmentData.doctor_name || 'Dr. Health Assistant',
        date: appointmentData.date,
        time: appointmentData.time,
        symptoms: appointmentData.symptoms || 'N/A',
        status: 'confirmed',
        timestamp: new Date().toISOString()
      };
      
      setSessionAppointments(prev => [newHistoryItem, ...prev]);
    }
  };

  const handleLogout = () => {
    setUser(null);
    setSessionAppointments([]); // Clear session data on logout
    setActiveTab("dashboard");
  };

  const handleCancelSessionAppointment = (id: string) => {
    setSessionAppointments(prev => prev.map(apt => 
      apt.id === id ? { ...apt, status: 'cancelled' } : apt
    ));
  };

  if (!user) {
    return <AuthPage onLogin={setUser} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2 rounded-xl shadow-lg shadow-blue-100">
                <Stethoscope className="w-6 h-6 text-white" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-xl font-bold tracking-tight">Health Clinic</h1>
                <p className="text-xs text-slate-500 font-medium uppercase tracking-widest">Autonomous Intake System</p>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => setActiveTab("dashboard")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                  activeTab === "dashboard" 
                    ? "bg-white text-blue-600 shadow-sm" 
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                <LayoutDashboard className="w-4 h-4" />
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab("availability")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                  activeTab === "availability" 
                    ? "bg-white text-blue-600 shadow-sm" 
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                <Calendar className="w-4 h-4" />
                Check Availability
              </button>
            </nav>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-full border border-slate-100">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                <User className="w-4 h-4" />
              </div>
              <div className="text-sm">
                <p className="font-bold text-slate-900 leading-none">{user.name}</p>
                <p className="text-xs text-slate-500">{user.email}</p>
              </div>
            </div>
            
            <button 
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-red-500 hover:bg-red-50 border border-transparent hover:border-red-100 rounded-xl transition-all"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden flex border-t border-slate-100">
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`flex-1 flex flex-col items-center py-3 gap-1 text-[10px] font-bold uppercase tracking-wider ${
              activeTab === "dashboard" ? "text-blue-600 border-b-2 border-blue-600" : "text-slate-400"
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab("availability")}
            className={`flex-1 flex flex-col items-center py-3 gap-1 text-[10px] font-bold uppercase tracking-wider ${
              activeTab === "availability" ? "text-blue-600 border-b-2 border-blue-600" : "text-slate-400"
            }`}
          >
            <Calendar className="w-5 h-5" />
            Availability
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        {activeTab === "dashboard" ? (
          <div className="grid lg:grid-cols-[400px_1fr] gap-12 items-start">
            {/* Left Column: Voice Interface */}
            <div className="lg:sticky lg:top-32">
              <VoiceReceptionist onAppointmentBooked={handleRefresh} />
              
              <div className="mt-8 p-6 bg-blue-900 rounded-3xl text-blue-50 shadow-xl shadow-blue-900/20">
                <h3 className="font-bold mb-2">How to use</h3>
                <ul className="text-sm space-y-3 text-blue-100/80">
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-400">01.</span>
                    Click "Call Clinic" to start talking.
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-400">02.</span>
                    Ask to book, check, or cancel an appointment.
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-400">03.</span>
                    The AI will handle your request automatically.
                  </li>
                </ul>
              </div>
            </div>

            {/* Right Column: Dashboard */}
            <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-200 overflow-hidden">
              <ClinicDashboard 
                sessionAppointments={sessionAppointments} 
                onCancel={handleCancelSessionAppointment} 
              />
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-200 overflow-hidden">
            <DoctorAvailability 
              user={user} 
              onBookingSuccess={handleRefresh} 
              onNavigateToDashboard={() => setActiveTab("dashboard")}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-slate-200 mt-12">
        <p className="text-center text-slate-400 text-sm">
          &copy; 2026 Health Clinic. Powered by Gemini Multimodal Live AI.
        </p>
      </footer>
    </div>
  );
}
